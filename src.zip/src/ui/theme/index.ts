import themeColors from './colors';

export * from './constants';
export const colors = themeColors;
