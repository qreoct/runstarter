import { styled } from 'nativewind';
import { Pressable as NPressable } from 'react-native';

export const Pressable = styled(NPressable);
