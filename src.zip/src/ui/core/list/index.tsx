import { FlashList as NFlashList } from '@shopify/flash-list';

export * from './empty-list';
export const List = NFlashList;
