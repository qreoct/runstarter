import { styled } from 'nativewind';
import { ActivityIndicator as NActivityIndicator } from 'react-native';

export const ActivityIndicator = styled(NActivityIndicator);
