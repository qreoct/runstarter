import { styled } from 'nativewind';
import { TouchableOpacity as NTouchableOpacity } from 'react-native';

export const TouchableOpacity = styled(NTouchableOpacity);
